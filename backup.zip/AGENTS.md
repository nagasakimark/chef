# AGENTS.md

## Loop: Manager → Worker

### Primary Agent: The Quality Manager (Critic)
- **Role:** You do not write raw feature code yourself. Your job is to enforce absolute perfection, test compliance, and formatting.
- **Rules:**
  1. Whenever the user requests a feature, you must delegate the raw task to a `sub-agent` (The Worker) via the Task tool.
  2. Once the Worker passes its draft back to you, you must check its work. You must encourage the worker to keep working until we have a fully feature-rich application with no bugs, weird graphical issues or other problems.
  3. If tests fail, or code style is sloppy, you must reject the output and re-prompt the sub-agent with exact error lines. Do not stop looping until you believe this app is fully feature-rich and ready for use by my students. Do not accept things like sloppy placeholder art or subpar, unfun graphics, animations text etc. that all exist to make this fun for my users.

### Sub-Agent: The Builder (Worker)
- **Role:** Focused entirely on high-velocity code and logic generation.
- **Rules:** Take prompts from the Quality Manager, execute changes inside the workspace, and present a structured summary of changes back to the Manager.

## Product Context — Food Maker
- Classroom-ready bilingual (EN/JA) game for Japanese students 8–14: practice English food words + world geography by building Champon / Pizza / Burger / Sandwich. Every screen must be colorful, chunky, kawaii, and instantly legible on Chromebooks/tablets — never minimal/corporate.
- Two learning loops per play: (1) pick 3 ingredients → confirm `name`/`nameJa` → pick country (flag + `COUNTRY_LIST` `name`/`nameJa`) → (2) build food mode-specifically. Keep EN and JA visible on every confirm/result row.
- Student-fun bar: reject thin icons, unstyled text, static screens, quiet audio, or placeholder art. Demand bouncy animations (`bob`, `pillPop`, `screenIn`, `confetti`, `chefBob`), big photo bases (`pizzabase.png`, `champonbowl.png`), melted-cheese overlays, and chatty JP/EN hints (`これでいい？`, `Pick a yummy thing!`).

## Run
- Static site — no build, no `package.json`, no bundler. Open `index.html` directly or serve locally:
  ```powershell
  python -m http.server 8000
  # then http://localhost:8000
  ```
- No tests, linter, or CI workflows in repo. Verify manually in browser; check console for JS errors.

## Architecture
- Entrypoint: `index.html` loads 4 global scripts **in order** — `js/data.js` -> `js/audio.js` -> `js/art.js` -> `js/game.js`. Do not reorder; they share globals (`INGREDIENTS`, `COUNTRIES`, `Art`, `AudioFx`). No ES modules.
- `js/data.js:1` — single source for `COUNTRY_LIST` (83 entries), `INGREDIENTS` (~95 entries via `food()` helper), `PIZZA_SAUCES`, `CHEESES`, `LAYER_STYLES`, `VIRTUAL_INGREDIENTS`. `INGREDIENT_ALIASES` maps virtual ids (tuna/beef/lettuce/ham) to real SVG files.
- `js/art.js:1` — pure HTML/SVG string builders (`Art.bowl`, `Art.pizza`, `Art.stack`, `Art.ovenScene`). Depends on `data.js` globals. Pizza cooked state uses photo overlays `assets/meltedcheddar.png` / `assets/meltedmozarella.png` (note single-z spelling matches `CHEESES` canonical handling).
- `js/game.js:1` — all state + DOM + flow in one IIFE. `state.mode` = `champon|pizza|burger|sandwich`, `TOTAL=3` picks shared by all modes. After 3× (ingredient → country) picks, modes diverge: champon→`cookChampon()`, pizza→sauce canvas→cheese→topping drag, burger/sandwich→stack. `showScreen()` toggles `.is-active` on `section.screen`.
- `js/audio.js:1` — Web Audio API (`AudioContext`); `AudioFx.unlock()` must be called on user gesture before tones play.
- `css/game.css` — single stylesheet, CSS vars in `:root`. Responsive breakpoints at `1100px` / `700px` + `max-height:700px`.
- `assets/` — `food/*.svg` (Twemoji), `flags/*.svg` (flag-icons `4x3`), plus PNGs: `chef.png`, `pizzachef.png`, `burgerchef.png`, `sandwichchef.png`, `champonbowl.png`, `pizzabase.png`, `melted*.png`.

## Adding Ingredients / Flags
- Add to `js/data.js:98` `INGREDIENTS` via `food(id, name, nameJa, file)` where `file` is basename of `assets/food/<file>.svg` without extension. `ingredientsflags.txt` is **unused legacy reference** — do not edit for functionality.
- New flag: add entry to `COUNTRY_LIST` in `js/data.js:1` with `code` matching `assets/flags/<code>.svg`, then add SVG file. Country `id` is the lookup key (e.g. `japan`), `code` is the filename key (e.g. `jp`).
- Virtual ingredients (no dedicated SVG) go in `VIRTUAL_INGREDIENTS` + `INGREDIENT_ALIASES` in `js/data.js:265`.
- Cheese ids: canonical are `cheddar`/`mozzarella`/`both`; `mozarella` (single z) and `mix` are aliased in `getCheese()` — keep alias handling if renaming.
- Re-download assets: `python scripts/download_assets.py` fetches from `cdn.jsdelivr.net` (Twemoji + flag-icons). Requires network.

## Gotchas
- Script order matters — editing `index.html:224` script tags or converting to modules breaks globals.
- Sauce painting: `js/game.js:413` `buildPaintCanvas()` creates a 480×480 `<canvas>` once per `pizzaSession`; `paintBuiltFor` guard prevents rebuild. `sauce-dabs` → `sauceFill` width; `captureSauce()` snapshots to `state.pizza.sauceUrl` data URL — must be called before leaving sauce screen.
- Pizza topping flow is manual placement only (`isOverPizza` + `clampToPizza`); no auto-scatter. `MAX_TOPS=12`, `MAX_PER_TOPPING=4` enforced in `addPizzaDrop()`; `COOK` requires each of the 3 picked ingredients placed at least once (`pizzaReadyToCook()`).
- Burger/sandwich `CLEAR` resets to `state.picks` layers, not empty — intentional (`js/game.js:1299`).
- `assets/meltedmozarella.png` filename intentionally single-z; code references it verbatim — renaming breaks `CHEESES.mozzarella.meltImg`.
- No package manager — do not add `package.json`/`node_modules` unless explicitly requested.

## Quality Bar (Manager Enforcement)
- No placeholder text: every button/label needs chunky `var(--font-display)` + `text-shadow` + `box-shadow: var(--shadow)`. No raw `<select>`/`alert`.
- Verify manually — no test harness: play all 4 modes front-to-back on desktop, `700px` narrow, and `max-height:700px`; hit BACK/START OVER from every screen and confirm `state.picks`/`state.pending`/`pizzaSession`/`sauceUrl` not corrupted. Watch console for JS errors and for missing `assets/food/*.svg` or `assets/flags/*.svg`.
- Audio must bob/celebrate loudly: every mode-select, ingredient/country confirm (`AudioFx.select`/`country`), `flyToBowl`/`whoosh`, `cook` steps, and `celebrate`+`burstConfetti()` on result.
